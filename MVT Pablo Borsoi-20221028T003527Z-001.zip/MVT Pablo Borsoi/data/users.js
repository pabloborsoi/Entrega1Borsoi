// BASE DE DATOS

let users = [
    {
        id: 1,
        nombre: "Claudio",
        apellido: "Gomez",
        edad: 24
    },
    {
        id: 2,
        nombre: "Juan",
        apellido: "Perez",
        edad: 20
    },
    {
        id: 3,
        nombre: "Diego",
        apellido: "Lopez",
        edad: 28
    }
]

module.exports = users;